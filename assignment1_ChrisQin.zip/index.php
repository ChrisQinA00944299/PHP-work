<!DOCTYPE html>
<html lang="en">
<title>Assignment 1</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
</style>
<body>

<div class="w3-content" style="max-width:2000px;margin-top:46px">
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
    <h2 class="w3-wide">Welcome to Index.php</h2>
    <p class="w3-opacity"><i>This is an open-sourced template from W3Schools and is not my own work</i></p>
    <p class="w3-center">Please choose one of the following two options:</p>
    <div class="w3-row w3-padding-32">
        <a href="login.php"><button type="button">Login</button></a>
        <a href="signup.php"><button type="button">Sign-Up</button></a>
    </div>
</div>
</body>
</html>

