<!DOCTYPE html>
<html>
<head>
    <title>Assignment 1</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>


<div class="panel-body">
    <form role="form" action="redirect.php" method="post" enctype="multipart/form-data">
        <fieldset>
            <div class="form-group">
                <input class="form-control" name="login_username" placeholder="Username" type="text"/>
            </div>
            <div class="form-group">
                <input class="form-control" name="login_password" placeholder="Password" type="password"/>
            </div>
            <input type="hidden" name="login"/>
            <input type="submit" class="btn btn-lg btn-info btn-block" value="Login"/>
        </fieldset>
    </form>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>