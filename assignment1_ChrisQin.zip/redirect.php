<?php 

$username_pattern = "/^[a-zA-Z0-9]{8,15}$/";
$password_pattern = "/^(?=.*[A-Za-z])(?=.*\d)(?=.+[@!?|])[A-Za-z\d@!?|]{8,}$/";

$salt = trim(file_get_contents("http://www.randomnumberapi.com/api/v1.0/randomuuid"), '[""]');

if ($_SERVER['REQUEST_METHOD'] === "GET") {
    header("Location: index.php");
}

if (isset($_POST['signup'])) {
    $username        = preg_replace("/-/", "", trim($_POST["signup_username"]));
    $password        = preg_replace("/-/", "", trim($_POST["signup_password"]));
    $verify_password = preg_replace("/-/", "", trim($_POST["verify_password"]));

    $username_validate  = preg_match($username_pattern, $username);
    $password_validate  = preg_match($password_pattern, $password);

    $hashed_password = md5($password . $salt);

    if($username_validate && $password_validate && $password == $verify_password)
    {                
        $poor_mans_database = fopen("users.txt", "a+");
    
        $to_write = $username . "|" /*. $hashed_password . "|"*/ . $password . PHP_EOL;
    
        fwrite($poor_mans_database, $to_write);
        fclose($poor_mans_database);
        header("Location: thankyou.php?type=signup&user=" . $username);
    } 
    else 
    {
        header("Location: signup.php"); 
    }
}

if (isset($_POST['login'])) {
    header('Content-Type: text/plain');

    $username        = preg_replace("/-/", "", trim($_POST["login_username"]));
    $password        = preg_replace("/-/", "", trim($_POST["login_password"]));

    $username_validate  = preg_match($username_pattern, $username);
    $password_validate  = preg_match($password_pattern, $password);

    $filecontent = file_get_contents("users.txt");
    $searchforuser = $username . "|" . $password;

    if(file_exists("users.txt") && $username_validate && $password_validate)
    {
        if (strpos($filecontent, $searchforuser) !== false) {
            header("Location: thankyou.php?type=login&user=" . $username);
        }
    }
    else 
    {
        header("Location: index.php");
    }
}

        //   if(isset($_POST["remember"]))
        //   {
        //       setcookie("username", $username, time() + 86400 * 30);
        //       setcookie("remember", "on", time() + 86400 * 30);
        //   }
        //   else 
        //   {
        //       echo 'No Cookies were tracked.';
        //   }

?>
