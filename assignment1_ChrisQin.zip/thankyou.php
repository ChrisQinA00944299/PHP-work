<!DOCTYPE html>
<html>
<head>
    <title>Assignment 1</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

<div style='text-align:center;font-size:30px;'>
    Thank you!
</div>
<div style='text-align:center;font-size:15px;font-style:italic'>
    <?php 
        if($_GET['type'] == "signup") { 
            echo "For signing up, <b>" . $_GET['user'] . "</b>!";
        } 

        if($_GET['type'] == "login") { 
            echo "For logging in, <b>" . $_GET['user'] . "</b>!";
        } 
    ?>
</div>


<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>