<html>
<body>

<form action="results.php" method="get">
Term: <input type="text" name="term" placeholder="Enter a term to search"><br>
<input type="submit">
</form>

</body>
</html>