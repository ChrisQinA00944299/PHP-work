<?php

$countries = [
    'cAnAdA',
    'cAnAdA',
    'cAnAdA',
    'cAnAdA',
    'cAnAdA',
    'SwitZerLand',
    'GrEEce',
    'HUnGary',
    'CroATia',
    'IndOneSia',
    'IrElAnd',
    'InDia',
    'MonGoLia',
    'UNitED StaTes of AmeriCA',
    'ChiNa',
    'romaNia',
    'Poland',
    'SieRRA LeoNe',
    'fraNcE',
    'JaPAn',
    'Belgium',
    'TuRkEy',
    'Aland islANds',
    'YeMen',
    'Egypt',
];

$term = $_GET['term'];

function searchCountries($term, $countries) {
    $results = "<table>";
    $existing  = [];

    foreach ($countries as $country) 
    {
        if (str_contains(strtolower($country), strtolower($term)))
        {
            if (in_array($country, $existing)) 
            {
                continue;
            } 
            else 
            {
                $existing[] = $country;
                $results = $results . "<tr><td>" . $country . "</td><td>" . ucwords(strtolower($country)) . "</td></tr>";
            }
        }
    }

    $results = $results . "</table>";

    return $results;
}

if (empty($term))
{
    echo "Cannot have an empty term.";
} else {
    echo searchCountries($term, $countries);
}

?>