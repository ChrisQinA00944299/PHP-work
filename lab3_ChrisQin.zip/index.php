<html>
<body>

<form action="results.php" method="post" enctype="multipart/form-data">
    Username: <input type="text" name="username" placeholder="Enter username" required><br>
    Password: <input type="password" name="password"><br>
    First Name: <input type="text" name="fname" placeholder="Enter your first name" required><br>
    Last Name: <input type="text" name="lname" placeholder="Enter your last name" required><br>
    Profile Picture: <input type="file" name="userfile" required><br>
    <input type="submit" value="Upload">
</form>

</body>
</html>