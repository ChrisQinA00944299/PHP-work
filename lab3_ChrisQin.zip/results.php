<?php

// echo $_FILES['userfile']['name'];       // the original name
// echo '<br/>';
// echo $_FILES['userfile']['type'];       // the mime-type the client browser/os thinks this file is
// echo '<br/>';
// echo $_FILES['userfile']['tmp_name'];   // the temporary location of the file
// echo '<br/>';
// echo $_FILES['userfile']['size'];       // the size in bytes of the file

// check image files for jpeg only (also have code to check for png and jpg)
// check if file size is less than 2,000,000 bytes or 2MB

// if(in_array($_FILES['userfile']['type'], array('image/jpeg', 'image/jpg', 'image/png') 

if($_FILES['userfile']['type'] == 'image/jpeg'
    && $_FILES['userfile']['size'] < 2000000)
{
    // create the 'uploads' directory if one doesnt exist
    if (!is_dir("uploads/")) {
        mkdir("uploads/");
    }
    
    // makes file directory for image takes a hash of the microtime plus a random integer with '.png'
    $file_directory = 'uploads/' . md5(rand(0, 1000000000) . microtime()) . '.png';

    // move the file from the temporary source folder to the uploads directory
    move_uploaded_file(
        $_FILES['userfile']['tmp_name'],  // this is the temporary source folder
        $file_directory  
    );

    // output for username, first & last name, and image
    $output = "<table>";
    $output = $output . "<tr><td><b>Username:</b></td><td>" . $_POST['username'] . "</td></tr>";
    $output = $output . "<tr><td><b>Full Name:</b></td><td>" . $_POST['fname'] . " " . $_POST['lname'] . "</td></tr>";
    $output = $output . "</table>";
    $output = $output . "<img src='" . $file_directory . "'/>";

    echo $output;  
}
else
{
    echo 'bad file!';
}

?>
