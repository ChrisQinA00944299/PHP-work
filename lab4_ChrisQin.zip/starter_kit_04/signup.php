<?php 

$username        = preg_replace("/-/", "", trim($_POST["username"]));
$password        = preg_replace("/-/", "", trim($_POST["password"]));
$verify_password = preg_replace("/-/", "", trim($_POST["verify_password"]));
$email           = preg_replace("/-/", "", trim($_POST["email"]));

$username_pattern = "/^([a-z]{1})(\w{6,})(\d{1}$)/i";
$password_pattern = "/(?=.{8,}$)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[ \.\,\/\?\*\!]).*/";
$email_pattern    = "/(?=.{15,}$)^[a-z]{1}[\w]*[.|+]?[\w]*[a-z0-9]{1}@(bcit\.ca|gmail\.com)/i";

$username_validate  = preg_match($username_pattern, $username);

$password_validate  = preg_match($password_pattern, $password);

$email_validate     = preg_match($email_pattern, $email);

if(!$username_validate || !$password_validate || !$email_validate || $password != $verify_password ||
  empty($username) || empty($password) || empty($email))
{
  header("Location: index.html");
}
else 
{
  echo "Thank you, " . $username . " for signing up with us!";
}

?>